# to use the simulator:
# 1. unzip the simulator.zip in the directory that has your submission.py file
# 2. cd ./simulator (you have to be in the directory that has the simulation_runner.py )
# 3. run the simulation_runner.py as you would any other python file

# it may take a long time to run the entire simulation, you can change how many times you want each pair of agents to face off by changing the agents list at the beginning of the ./simulator/simulation_runner.py which by default runs all possible match ups. feel free to make that change to check certain agents more than others.

# the statistics are found in the ./simulator/output/exec_file.csv with the output from each pair that face off named as agent_0_vs_agent_1.txt and similarly if there was an error during runtime the errors are printed in a file called agent_0_vs_agent_1.txt which can be found in ./simulator/errors/